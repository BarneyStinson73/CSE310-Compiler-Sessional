int a, b;

float x, y;

int add_int(int-) {
    return 5;
}

int main() {
    int p-q, r;

    a = 2 + = 4;
    x = 2.3;

    return 0;
}
